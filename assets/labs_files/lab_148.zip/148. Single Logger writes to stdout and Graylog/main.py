import uvicorn

from src.config import CONFIG


def start():
    try:
        uvicorn.run(
            "src.app:app", host=CONFIG.APP_HOST, port=CONFIG.APP_PORT, workers=CONFIG.APP_WORKERS
        )
    finally:
        print("stopping server:app...")


if __name__ == "__main__":
    start()