import os

from dotenv import find_dotenv
from dotenv import load_dotenv

load_dotenv(find_dotenv())


class CONFIG:
    ENV: str = "development"
    PROJECT_NAME: str = "Lab 148"
    APP_PORT: int = int(os.getenv("APP_PORT", 8080))
    APP_HOST: str = os.getenv("APP_HOST", "0.0.0.0")
    APP_WORKERS: int = int(os.getenv("APP_WORKERS", 1))
    SEND_LOGS_TO_GRAYLOG: bool = True
    GRAYLOG_HOST: str = os.getenv("GRAYLOG_HOST")
    GRAYLOG_PORT: int = int(os.getenv("GRAYLOG_PORT", 12201))
