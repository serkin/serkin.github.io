from fastapi import FastAPI
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
import time
from src.logger import logger, graylog
from src.config import CONFIG

class CustomMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        response = await call_next(request)
        end_time = time.time()
        time_taken = end_time - start_time

        if CONFIG.SEND_LOGS_TO_GRAYLOG and hasattr(logger, 'memory_handler'):
            logger.info("Закончили запрос")
            log = logger.memory_handler.dump()
            extra={
                "http_status_code": response.status_code,
                "time_taken": time_taken,
                "method": request.method,
                "host": request.url.netloc,
                "path": request.url.path,
                "env": CONFIG.ENV,
                "service": CONFIG.PROJECT_NAME
            }
            graylog.info(log, extra=extra)
        return response

app = FastAPI(
    lifespan=None,
    description="Description",
)
app.add_middleware(CustomMiddleware)


@app.get("/emulate")
def emulate_work():
    logger.info("info")

    logger.warning("warning")
    logger.debug("debug")
    logger.error("error")

    return {"message": "Work emulation completed"}