import logging
import sys
import graypy
from src.config import CONFIG
from colorlog import ColoredFormatter

class MemoryHandler(logging.Handler):
    def __init__(self):
        super().__init__()
        self.log_messages = []

    def emit(self, record):
        log_entry = self.format(record)
        self.log_messages.append(log_entry)

    def dump(self) -> str:
        log_messages = "\n".join(self.log_messages)
        self.log_messages.clear()
        return log_messages


def custom_formatter(level):
    if level >= logging.ERROR:
        fmt = '%(levelname)s: %(message)s'
    else:
        fmt = '%(message)s'
    return logging.Formatter(fmt)

  
class Logger(logging.Logger):
    def __init__(self, name):
        super().__init__(name)

        if name == "graylog":
            graylog_handler = graypy.GELFUDPHandler(CONFIG.GRAYLOG_HOST, CONFIG.GRAYLOG_PORT)
            graylog_handler.setLevel(logging.DEBUG)
            self.addHandler(graylog_handler)
        else:
            stream_handler = logging.StreamHandler(sys.stdout)
            stream_handler.setLevel(logging.DEBUG)

            colored_formatter = ColoredFormatter('%(asctime)s %(log_color)s%(levelname)s: %(message)s')
            stream_handler.setFormatter(colored_formatter)
            self.addHandler(stream_handler)

            self.memory_handler = MemoryHandler()
            self.memory_handler.setLevel(logging.DEBUG)
            self.addHandler(self.memory_handler)

    def handle(self, record):
        custom_fmt = custom_formatter(record.levelno)
        if hasattr(self, 'memory_handler'):
            self.memory_handler.setFormatter(custom_fmt)
        super().handle(record)

logger = Logger("stdout+memory")
graylog = Logger("graylog")
